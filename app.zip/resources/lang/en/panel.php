<?php

return [
    'site_title' => 'ASE',
];
