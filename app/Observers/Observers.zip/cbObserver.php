<?php

namespace App\Observers;

use App\Models\cb;

use App\Notifications\DataChangeEmailNotification;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\DB;

class cbObserver
{
    /**
     * Handle the cb "created" event.
     *
     * @param  \App\Models\cb  $cb
     * @return void
     */
    public function created(cb $cb)
    {
        // $cb_id = $cb ->id;
        // $transe_id = $cb ->transe_id;
        // $saveHistory2 = DB::table('cb_transeformer') 
        // ->insert( ['transeformer_id' =>  $transe_id, 'cb_id' => $cb_id ]
        // );
        // return $saveHistory2 ;

    //    dd($transe_id);
    }

    /**
     * Handle the cb "updated" event.
     *
     * @param  \App\Models\cb  $cb
     * @return void
     */
    public function updated(cb $cb)
    {
        //
    }

    /**
     * Handle the cb "deleted" event.
     *
     * @param  \App\Models\cb  $cb
     * @return void
     */
    public function deleted(cb $cb)
    {
        //
    }

    /**
     * Handle the cb "restored" event.
     *
     * @param  \App\Models\cb  $cb
     * @return void
     */
    public function restored(cb $cb)
    {
        //
    }

    /**
     * Handle the cb "force deleted" event.
     *
     * @param  \App\Models\cb  $cb
     * @return void
     */
    public function forceDeleted(cb $cb)
    {
        //
    }
}
