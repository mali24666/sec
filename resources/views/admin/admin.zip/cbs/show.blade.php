@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    {{ trans('global.show') }} {{ trans('cruds.cb.title') }}
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="form-group">
                            <a class="btn btn-default" href="{{ route('admin.cbs.index') }}">
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>
                                        {{ trans('cruds.cb.fields.id') }}
                                    </th>
                                    <td>
                                        {{ $cb->id }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.cb.fields.trans_cb_fider_number') }}
                                    </th>
                                    <td>
                                        {{ $cb->trans_cb_fider_number }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.cb.fields.minbilar') }}
                                    </th>
                                    <td>
                                        @foreach($cb->minbilars as $key => $minbilar)
                                            <span class="label label-info">{{ $minbilar->minibller_number }}</span>
                                        @endforeach
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.cb.fields.temperature') }}
                                    </th>
                                    <td>
                                        {{ $cb->temperature }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.cb.fields.temperature_refrence') }}
                                    </th>
                                    <td>
                                        {{ $cb->temperature_refrence }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.cb.fields.temperature_picture') }}
                                    </th>
                                    <td>
                                        @foreach($cb->temperature_picture as $key => $media)
                                            <a href="{{ $media->getUrl() }}" target="_blank" style="display: inline-block">
                                                <img src="{{ $media->getUrl('thumb') }}">
                                            </a>
                                        @endforeach
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-group">
                            <a class="btn btn-default" href="{{ route('admin.cbs.index') }}">
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    {{ trans('global.relatedData') }}
                </div>
                <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
                    <li role="presentation">
                        <a href="#minibller_no_boxes" aria-controls="minibller_no_boxes" role="tab" data-toggle="tab">
                            {{ trans('cruds.box.title') }}
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane" role="tabpanel" id="minibller_no_boxes">
                        @includeIf('admin.cbs.relationships.minibllerNoBoxes', ['boxes' => $cb->minibllerNoBoxes])
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection