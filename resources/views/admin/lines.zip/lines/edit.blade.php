@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.line.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.lines.update", [$line->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label for="station_id">{{ trans('cruds.line.fields.station') }}</label>
                <select class="form-control select2 {{ $errors->has('station') ? 'is-invalid' : '' }}" name="station_id" id="station_id">
                    @foreach($stations as $id => $entry)
                        <option value="{{ $id }}" {{ (old('station_id') ? old('station_id') : $line->station->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('station'))
                    <span class="text-danger">{{ $errors->first('station') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.station_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="line_no">{{ trans('cruds.line.fields.line_no') }}</label>
                <input class="form-control {{ $errors->has('line_no') ? 'is-invalid' : '' }}" type="text" name="line_no" id="line_no" value="{{ old('line_no', $line->line_no) }}">
                @if($errors->has('line_no'))
                    <span class="text-danger">{{ $errors->first('line_no') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.line_no_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="trans">{{ trans('cruds.line.fields.trans') }}</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0">{{ trans('global.deselect_all') }}</span>
                </div>
                <select class="form-control select2 {{ $errors->has('trans') ? 'is-invalid' : '' }}" name="trans[]" id="trans" multiple>
                    @foreach($trans as $id => $tran)
                        <option value="{{ $id }}" {{ (in_array($id, old('trans', [])) || $line->trans->contains($id)) ? 'selected' : '' }}>{{ $tran }}</option>
                    @endforeach
                </select>
                @if($errors->has('trans'))
                    <span class="text-danger">{{ $errors->first('trans') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.trans_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="cts">{{ trans('cruds.line.fields.ct') }}</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0">{{ trans('global.deselect_all') }}</span>
                </div>
                <select class="form-control select2 {{ $errors->has('cts') ? 'is-invalid' : '' }}" name="cts[]" id="cts" multiple>
                    @foreach($cts as $id => $ct)
                        <option value="{{ $id }}" {{ (in_array($id, old('cts', [])) || $line->cts->contains($id)) ? 'selected' : '' }}>{{ $ct }}</option>
                    @endforeach
                </select>
                @if($errors->has('cts'))
                    <span class="text-danger">{{ $errors->first('cts') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.ct_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="boxx_numbers">{{ trans('cruds.line.fields.boxx_number') }}</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0">{{ trans('global.deselect_all') }}</span>
                </div>
                <select class="form-control select2 {{ $errors->has('boxx_numbers') ? 'is-invalid' : '' }}" name="boxx_numbers[]" id="boxx_numbers" multiple>
                    @foreach($boxx_numbers as $id => $boxx_number)
                        <option value="{{ $id }}" {{ (in_array($id, old('boxx_numbers', [])) || $line->boxx_numbers->contains($id)) ? 'selected' : '' }}>{{ $boxx_number }}</option>
                    @endforeach
                </select>
                @if($errors->has('boxx_numbers'))
                    <span class="text-danger">{{ $errors->first('boxx_numbers') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.boxx_number_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="avr_nos">{{ trans('cruds.line.fields.avr_no') }}</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0">{{ trans('global.deselect_all') }}</span>
                </div>
                <select class="form-control select2 {{ $errors->has('avr_nos') ? 'is-invalid' : '' }}" name="avr_nos[]" id="avr_nos" multiple>
                    @foreach($avr_nos as $id => $avr_no)
                        <option value="{{ $id }}" {{ (in_array($id, old('avr_nos', [])) || $line->avr_nos->contains($id)) ? 'selected' : '' }}>{{ $avr_no }}</option>
                    @endforeach
                </select>
                @if($errors->has('avr_nos'))
                    <span class="text-danger">{{ $errors->first('avr_nos') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.avr_no_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="auto_selectors">{{ trans('cruds.line.fields.auto_selector') }}</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0">{{ trans('global.deselect_all') }}</span>
                </div>
                <select class="form-control select2 {{ $errors->has('auto_selectors') ? 'is-invalid' : '' }}" name="auto_selectors[]" id="auto_selectors" multiple>
                    @foreach($auto_selectors as $id => $auto_selector)
                        <option value="{{ $id }}" {{ (in_array($id, old('auto_selectors', [])) || $line->auto_selectors->contains($id)) ? 'selected' : '' }}>{{ $auto_selector }}</option>
                    @endforeach
                </select>
                @if($errors->has('auto_selectors'))
                    <span class="text-danger">{{ $errors->first('auto_selectors') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.auto_selector_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="section_lazeys">{{ trans('cruds.line.fields.section_lazey') }}</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0">{{ trans('global.deselect_all') }}</span>
                </div>
                <select class="form-control select2 {{ $errors->has('section_lazeys') ? 'is-invalid' : '' }}" name="section_lazeys[]" id="section_lazeys" multiple>
                    @foreach($section_lazeys as $id => $section_lazey)
                        <option value="{{ $id }}" {{ (in_array($id, old('section_lazeys', [])) || $line->section_lazeys->contains($id)) ? 'selected' : '' }}>{{ $section_lazey }}</option>
                    @endforeach
                </select>
                @if($errors->has('section_lazeys'))
                    <span class="text-danger">{{ $errors->first('section_lazeys') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.section_lazey_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="rmu_nos">{{ trans('cruds.line.fields.rmu_no') }}</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0">{{ trans('global.deselect_all') }}</span>
                </div>
                <select class="form-control select2 {{ $errors->has('rmu_nos') ? 'is-invalid' : '' }}" name="rmu_nos[]" id="rmu_nos" multiple>
                    @foreach($rmu_nos as $id => $rmu_no)
                        <option value="{{ $id }}" {{ (in_array($id, old('rmu_nos', [])) || $line->rmu_nos->contains($id)) ? 'selected' : '' }}>{{ $rmu_no }}</option>
                    @endforeach
                </select>
                @if($errors->has('rmu_nos'))
                    <span class="text-danger">{{ $errors->first('rmu_nos') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.line.fields.rmu_no_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection